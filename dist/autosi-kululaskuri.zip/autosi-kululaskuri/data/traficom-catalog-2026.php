<?php
/** Generated from Traficom open data. Do not edit manually. */
defined( 'ABSPATH' ) || exit;

return json_decode( '{"count":1,"brands":["Volvo"],"vehicleTypes":["passenger"],"models":[{"brand":"Volvo","model":"XC60","vehicle_type":"passenger","powertrains":["diesel"]}],"availability":{"Volvo":{"passenger":["diesel"]}}}', true );
